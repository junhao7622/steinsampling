# Custom base-kernel objects and their optional FSSD capabilities.
#
# A custom kernel has the same three mathematical leaves as a built-in base
# kernel: value, first-argument gradient, and mixed-derivative trace. This file
# owns the callback boundary and validates every value before package algorithms
# consume it. The general Stein-matrix assembly remains in kernel_classes.R.

# ---- Constructor ----------------------------------------------------------

#' Construct a SteinKernel from a custom base kernel
#'
#' Constructs a `SteinKernel` object from a custom base kernel
#' \eqn{k_\rho(x,y)} and its derivatives. Users do not supply the Stein kernel
#' \eqn{k_{0,p}(x,y)} directly; [stein_kernel_matrix()] combines the supplied
#' base-kernel pieces with target scores.
#'
#' @details
#' The constructor always requires `eval_fn`, `grad_x_fn`, and
#' `trace_mixed_fn`. KSD and [stein_kernel_matrix()] use all three. FSSD-rand
#' and SVGD use the first two, but the constructor still requires all three.
#' FSSD-opt additionally requires either an analytic `grad_theta_v_fn` or
#' `custom_grad_mode = "numeric"`. Optimizing a custom squared scale also
#' requires `scale_init`, `set_scale_fn`, and an analytic `grad_theta_v_fn`
#' returning both scale and location derivatives.
#'
#' Let rows of \eqn{X} and \eqn{Y} be \eqn{x_i^\top} and \eqn{y_j^\top}. The
#' three required callbacks have the following contracts:
#' \deqn{[\texttt{eval_fn}(X,Y,\texttt{precon})]_{ij}
#' =B_{ij}=k_\rho(x_i,y_j),}
#' \deqn{[\texttt{grad_x_fn}(X,Y,\texttt{precon})]_{ijr}
#' =G_{ijr}=\frac{\partial k_\rho(x_i,y_j)}{\partial x_r},}
#' \deqn{[\texttt{trace_mixed_fn}(X,Y,\texttt{precon})]_{ij}
#' =H_{ij}=\operatorname{tr}\left\{\nabla_x\nabla_y^\top
#' k_\rho(x_i,y_j)\right\}.}
#' Thus `eval_fn` and `trace_mixed_fn` return
#' \eqn{n_X\times n_Y} matrices, while `grad_x_fn` returns an
#' \eqn{n_X\times n_Y\times d} array. Each callback must accept
#' `Y = NULL`, meaning \eqn{Y=X}, and the `precon` argument. A callback that
#' does not use preconditioning may ignore `precon`.
#'
#' The object owns its default `precon`. All package algorithms therefore see
#' the same preconditioner. A non-`NULL` method-level `precon` is a temporary
#' override used by workflows such as Stein thinning.
#'
#' For a symmetric base kernel, the package obtains derivatives with respect to
#' \eqn{y} by swapping \eqn{X} and \eqn{Y}. A nonsymmetric kernel requires a
#' separate S3 class with its own [cross_kernel()] method.
#'
#' The analytic FSSD-opt callback must follow the local-objective contract in
#' [grad_theta_v_kernel()]. It returns `grad_vj`; if the object exposes a
#' squared scale \eqn{\rho}, it must also return `grad_param`. Numeric mode
#' differentiates locations only and cannot optimize \eqn{\rho}.
#'
#' @param eval_fn Function `(X, Y = NULL, precon = NULL)` returning the
#'   base-kernel matrix \eqn{B}.
#' @param grad_x_fn Function `(X, Y = NULL, precon = NULL)` returning the
#'   first-argument gradient array \eqn{G}.
#' @param trace_mixed_fn Function `(X, Y = NULL, precon = NULL)` returning the
#'   mixed-derivative trace matrix \eqn{H}.
#' @param grad_theta_v_fn Optional analytic FSSD-opt callback described in
#'   Details. It must return a list containing `grad_vj`, and also `grad_param`
#'   when the kernel exposes a squared scale.
#' @param scale_init Optional positive starting value of the custom squared
#'   scale \eqn{\rho}. It must be supplied with `set_scale_fn`.
#' @param set_scale_fn Optional function `(obj, scale2)` that returns `obj` with
#'   all scale-dependent callbacks rebuilt at `scale2`.
#' @param custom_grad_mode FSSD-opt gradient mode. `"analytic"` requires
#'   `grad_theta_v_fn`; `"numeric"` uses finite differences for test locations
#'   only. This argument is not used outside FSSD optimization.
#' @param precon Optional symmetric positive-definite matrix passed to every
#'   callback. A non-`NULL` `precon` supplied to a kernel method temporarily
#'   overrides this object-owned value.
#'
#' @return
#' A `SteinKernel_custom` object storing the callbacks and FSSD-opt settings.
#' @examples
#' difference <- function(X, Y = NULL) {
#'   X <- as.matrix(X)
#'   Y <- if (is.null(Y)) X else as.matrix(Y)
#'   outer(X[, 1], Y[, 1], "-")
#' }
#' eval_fn <- function(X, Y = NULL, precon = NULL) {
#'   exp(-difference(X, Y)^2 / 2)
#' }
#' grad_x_fn <- function(X, Y = NULL, precon = NULL) {
#'   d <- difference(X, Y)
#'   array(-d * exp(-d^2 / 2), dim = c(nrow(d), ncol(d), 1L))
#' }
#' trace_mixed_fn <- function(X, Y = NULL, precon = NULL) {
#'   d <- difference(X, Y)
#'   (1 - d^2) * exp(-d^2 / 2)
#' }
#' custom_stein_kernel(eval_fn, grad_x_fn, trace_mixed_fn)
#' @export
custom_stein_kernel <- function(eval_fn, grad_x_fn, trace_mixed_fn,
                                grad_theta_v_fn = NULL,
                                scale_init = NULL,
                                set_scale_fn = NULL,
                                custom_grad_mode = c("analytic", "numeric"),
                                precon = NULL) {
  if (!is.function(eval_fn) || !is.function(grad_x_fn) ||
      !is.function(trace_mixed_fn)) {
    stop(
      paste0(
        "eval_fn, grad_x_fn, and trace_mixed_fn must be functions accepting ",
        "(X, Y = NULL, precon = NULL)"
      ),
      call. = FALSE
    )
  }
  if (!is.null(grad_theta_v_fn) && !is.function(grad_theta_v_fn)) {
    stop("grad_theta_v_fn must be NULL or a function", call. = FALSE)
  }
  if (!is.null(set_scale_fn) && !is.function(set_scale_fn)) {
    stop("set_scale_fn must be NULL or a function", call. = FALSE)
  }
  if (is.null(set_scale_fn) && !is.null(scale_init)) {
    stop(
      "scale_init needs set_scale_fn; without it the scale cannot reach the callbacks",
      call. = FALSE
    )
  }
  if (!is.null(set_scale_fn)) {
    if (is.null(scale_init)) {
      stop("set_scale_fn needs scale_init, the starting squared scale",
           call. = FALSE)
    }
    scale_init <- validate_kernel_squared_scale(scale_init)
  }

  obj <- list(
    type = "custom",
    eval_fn = eval_fn,
    grad_x_fn = grad_x_fn,
    trace_mixed_fn = trace_mixed_fn,
    grad_theta_v_fn = grad_theta_v_fn,
    scale_init = scale_init,
    set_scale_fn = set_scale_fn,
    custom_grad_mode = match.arg(custom_grad_mode),
    precon = validate_kernel_precon(precon)
  )
  class(obj) <- c("SteinKernel_custom", "SteinKernel")
  if (!is.null(set_scale_fn)) .validate_custom_set_scale(obj)
  obj
}


# ---- Base-kernel leaves ---------------------------------------------------

#' @export
eval_kernel.SteinKernel_custom <- function(obj, X, Y = NULL, precon = NULL,
                                           ...) {
  inp <- validate_kernel_xy(X, Y)
  M <- kernel_precon(obj, precon, ncol(inp$X))
  callback_Y <- if (inp$y_was_null) NULL else inp$Y
  out <- obj$eval_fn(inp$X, callback_Y, M)
  validate_custom_matrix(out, "eval_fn", nrow(inp$X), nrow(inp$Y))
}

#' @export
grad_x_kernel.SteinKernel_custom <- function(obj, X, Y = NULL,
                                             precon = NULL, ...) {
  inp <- validate_kernel_xy(X, Y)
  M <- kernel_precon(obj, precon, ncol(inp$X))
  callback_Y <- if (inp$y_was_null) NULL else inp$Y
  out <- obj$grad_x_fn(inp$X, callback_Y, M)
  validate_custom_gradient(out, nrow(inp$X), nrow(inp$Y), ncol(inp$X))
}

#' @export
trace_mixed_kernel.SteinKernel_custom <- function(obj, X, Y = NULL,
                                                  precon = NULL, ...) {
  inp <- validate_kernel_xy(X, Y)
  M <- kernel_precon(obj, precon, ncol(inp$X))
  callback_Y <- if (inp$y_was_null) NULL else inp$Y
  out <- obj$trace_mixed_fn(inp$X, callback_Y, M)
  validate_custom_matrix(out, "trace_mixed_fn", nrow(inp$X), nrow(inp$Y))
}


# ---- Optional FSSD location and scale capabilities -----------------------

.custom_fssd_local_objective <- function(obj, X, vj, grads_X, g_block) {
  d <- ncol(X)
  v_one <- matrix(vj, nrow = 1, ncol = d)
  k_xv <- eval_kernel(obj, X, v_one)
  grad_arr <- grad_x_kernel(obj, X, v_one)
  grad_k <- matrix(0, nrow = nrow(X), ncol = d)
  for (l in seq_len(d)) grad_k[, l] <- grad_arr[, 1, l]
  k_vec <- as.numeric(k_xv[, 1])
  xi <- grads_X * k_vec + grad_k
  sum(g_block * xi)
}

#' @export
grad_theta_v_kernel.SteinKernel_custom <- function(
    obj, X, vj, grads_X, g_block, ...) {
  if (!is.null(obj$grad_theta_v_fn)) {
    out <- obj$grad_theta_v_fn(
      X = X, vj = vj, grads_X = grads_X, g_block = g_block, obj = obj
    )
    if (!is.list(out) || is.null(out$grad_vj)) {
      stop("grad_theta_v_fn must return a list with at least 'grad_vj'",
           call. = FALSE)
    }
    grad_vj <- as.numeric(out$grad_vj)
    if (length(grad_vj) != ncol(X) || any(!is.finite(grad_vj))) {
      stop("grad_theta_v_fn$grad_vj must be a finite vector of length ncol(X)",
           call. = FALSE)
    }
    if (is.null(kernel_scale2(obj))) {
      return(list(grad_vj = grad_vj, grad_param = 0))
    }
    if (is.null(out$grad_param)) {
      stop(
        "this kernel reports a scale, so grad_theta_v_fn must return grad_param",
        call. = FALSE
      )
    }
    grad_param <- as.numeric(out$grad_param)
    if (length(grad_param) != 1L || !is.finite(grad_param)) {
      stop("grad_theta_v_fn$grad_param must be a finite scalar", call. = FALSE)
    }
    return(list(grad_vj = grad_vj, grad_param = grad_param))
  }

  mode <- if (!is.null(obj$custom_grad_mode)) obj$custom_grad_mode else "analytic"
  if (identical(mode, "analytic")) {
    stop(
      "custom kernel optimization requires grad_theta_v_fn in analytic mode",
      call. = FALSE
    )
  }
  if (!identical(mode, "numeric")) {
    stop("Unknown custom_grad_mode for custom kernel optimization", call. = FALSE)
  }
  if (!is.null(kernel_scale2(obj))) {
    stop(
      paste0(
        "numeric differentiation of the kernel scale is not implemented; ",
        "supply grad_theta_v_fn with grad_param"
      ),
      call. = FALSE
    )
  }

  grad_vj <- numeric(length(vj))
  for (k in seq_along(vj)) {
    v_plus <- vj; v_minus <- vj
    v_plus[k] <- v_plus[k] + .fssd_numeric_grad_eps
    v_minus[k] <- v_minus[k] - .fssd_numeric_grad_eps
    f_plus <- .custom_fssd_local_objective(obj, X, v_plus, grads_X, g_block)
    f_minus <- .custom_fssd_local_objective(obj, X, v_minus, grads_X, g_block)
    grad_vj[k] <- (f_plus - f_minus) / (2 * .fssd_numeric_grad_eps)
  }
  list(grad_vj = grad_vj, grad_param = 0)
}

.fssd_numeric_grad_eps <- 1e-5

#' @export
kernel_scale2.SteinKernel_custom <- function(obj, value = NULL) {
  if (is.null(value)) {
    return(if (is.null(obj$set_scale_fn)) NULL else as.numeric(obj$scale_init))
  }
  if (is.null(obj$set_scale_fn)) {
    stop(
      "this custom kernel has no set_scale_fn, so its scale cannot be optimized",
      call. = FALSE
    )
  }
  value <- validate_kernel_squared_scale(value)
  out <- .validate_custom_kernel_object(
    obj$set_scale_fn(obj, value), "set_scale_fn"
  )
  if (!isTRUE(all.equal(out$precon, obj$precon))) {
    stop("set_scale_fn must preserve the custom kernel precon", call. = FALSE)
  }
  out$scale_init <- value
  out
}


# ---- Callback boundary validation ----------------------------------------

.validate_custom_set_scale <- function(obj) {
  probe <- .validate_custom_kernel_object(
    obj$set_scale_fn(obj, obj$scale_init * 2), "set_scale_fn"
  )
  if (!isTRUE(all.equal(probe$precon, obj$precon))) {
    stop("set_scale_fn must preserve the custom kernel precon", call. = FALSE)
  }
  rebuilt <- !c(
    identical(probe$eval_fn, obj$eval_fn),
    identical(probe$grad_x_fn, obj$grad_x_fn),
    identical(probe$trace_mixed_fn, obj$trace_mixed_fn)
  )
  if (!any(rebuilt)) {
    stop(
      "set_scale_fn left every callback unchanged, so the new scale would never be used",
      call. = FALSE
    )
  }
  invisible(obj)
}

.validate_custom_kernel_object <- function(obj, source = "custom kernel") {
  if (!inherits(obj, "SteinKernel_custom")) {
    stop(sprintf("%s must return a SteinKernel_custom object", source),
         call. = FALSE)
  }
  callbacks <- c("eval_fn", "grad_x_fn", "trace_mixed_fn")
  valid_callbacks <- vapply(obj[callbacks], is.function, logical(1L))
  if (length(valid_callbacks) != length(callbacks) || !all(valid_callbacks)) {
    stop(sprintf("%s must preserve eval_fn, grad_x_fn, and trace_mixed_fn", source),
         call. = FALSE)
  }
  obj$precon <- validate_kernel_precon(obj$precon)
  obj
}

validate_custom_matrix <- function(value, callback, n_x, n_y) {
  value <- as.matrix(value)
  if (!is.numeric(value) || !identical(dim(value), c(n_x, n_y))) {
    stop(sprintf("custom %s must return a numeric %d x %d matrix",
                 callback, n_x, n_y), call. = FALSE)
  }
  if (any(!is.finite(value))) {
    stop(sprintf("custom %s must return only finite values", callback),
         call. = FALSE)
  }
  value
}

validate_custom_gradient <- function(value, n_x, n_y, d) {
  # Retain the historical one-dimensional matrix convenience, but normalize it
  # immediately so every downstream consumer sees the documented array shape.
  if (d == 1L && is.matrix(value) && identical(dim(value), c(n_x, n_y))) {
    value <- array(value, dim = c(n_x, n_y, 1L))
  }
  if (!is.numeric(value) || is.null(dim(value)) ||
      !identical(dim(value), c(n_x, n_y, d))) {
    stop(sprintf(
      "custom grad_x_fn must return a numeric %d x %d x %d array",
      n_x, n_y, d
    ), call. = FALSE)
  }
  if (any(!is.finite(value))) {
    stop("custom grad_x_fn must return only finite values", call. = FALSE)
  }
  value
}
