# Stein-kernel objects and extension interface.
#
# Constructors create built-in or callback kernels. Leaf generics supply base-
# kernel values and derivatives; `stein_kernel_matrix()` assembles pairwise k0,
# while `k0_diag()` supports sequential algorithms. FSSD uses the leaf methods,
# and SVGD uses only the base kernel and its first derivative.
# RBF uses exp(-r/(2 h^2)), IMQ uses (c^2+r)^beta, and `precon = M` changes
# r(x,y) to (x-y)^T M (x-y).

# Validate the metric once at construction and again when its dimension becomes
# known at evaluation. Keeping this outside individual constructors gives
# built-in and callback kernels exactly the same preconditioner contract.
validate_kernel_precon <- function(precon, d = NULL) {
  if (is.null(precon)) return(NULL)
  precon <- as.matrix(precon)
  if (!is.numeric(precon) || nrow(precon) != ncol(precon) ||
      !all(is.finite(precon))) {
    stop("precon must be a finite square numeric matrix", call. = FALSE)
  }
  if (!is.null(d) && !identical(dim(precon), c(as.integer(d), as.integer(d)))) {
    stop(sprintf("precon must be a %d x %d matrix for these points", d, d),
         call. = FALSE)
  }
  sym_tol <- sqrt(.Machine$double.eps) * max(1, max(abs(precon)))
  if (max(abs(precon - t(precon))) > sym_tol) {
    stop("precon must be symmetric positive definite", call. = FALSE)
  }
  tryCatch(chol(precon), error = function(e) {
    stop("precon must be symmetric positive definite", call. = FALSE)
  })
  precon
}

# ---- 1. Constructors: build a kernel object ------------------------------

#' Construct a built-in base kernel
#'
#' Constructs a `SteinKernel` object containing a built-in base kernel and its
#' derivatives. The object does not contain a target score and is not an
#' already evaluated Stein kernel \eqn{k_{0,p}}.
#'
#' @details
#' Let \eqn{M} denote `precon` and
#' \deqn{r_M(x,y)=(x-y)^\top M(x-y).}
#' If `precon = NULL`, \eqn{M} is the identity matrix. The Gaussian RBF base
#' kernel is
#' \deqn{k_\rho^{\mathrm{RBF}}(x,y)=
#' \exp\left\{-\frac{r_M(x,y)}{2h^2}\right\},\qquad \rho=h^2.}
#' Here \eqn{h} is the bandwidth; `sigma` is an alias for `h`. The object stores
#' the squared scale \eqn{h^2}.
#'
#' The IMQ base kernel is
#' \deqn{k_\rho^{\mathrm{IMQ}}(x,y)=
#' \left\{c^2+r_M(x,y)\right\}^{\beta},\qquad
#' \rho=c^2,\quad \beta<0.}
#' Here \eqn{c} is the length scale and \eqn{c^2} is its squared scale.
#'
#' [stein_kernel_matrix()] combines the base kernel and its derivatives with
#' target scores to construct \eqn{k_{0,p}}. [custom_stein_kernel()] provides
#' the corresponding interface for a user-defined base kernel.
#'
#' @param type Kernel type, `"gaussian_rbf"` or `"imq"`.
#' @param sigma,h Positive Gaussian RBF bandwidth \eqn{h}. `sigma` is an alias
#'   for `h`; supply at most one. If both are `NULL`, algorithms that support an
#'   adaptive RBF scale determine \eqn{h^2} from the data.
#' @param beta Finite IMQ exponent \eqn{\beta<0}.
#' @param c Positive IMQ length scale \eqn{c}.
#' @param precon Optional symmetric positive-definite matrix \eqn{M}. `NULL`
#'   uses the identity matrix.
#'
#' @return
#' A `SteinKernel` object describing the selected base kernel and its
#' derivatives.
#' @examples
#' stein_kernel(type = "gaussian_rbf", h = 1)
#' stein_kernel(type = "imq", c = 1, beta = -0.5)
#' @export
stein_kernel <- function(type = c("gaussian_rbf", "imq"),
                         sigma = NULL, h = NULL, beta = -0.5, c = 1, precon = NULL) {
  type <- match.arg(type)
  if (!is.null(sigma) && !is.null(h))
    stop("provide at most one of `sigma` or `h`", call. = FALSE)
  bandwidth <- if (!is.null(h)) h else sigma

  if (type == "gaussian_rbf") {
    h2 <- NULL
    if (!is.null(bandwidth)) {
      if (!is.numeric(bandwidth) || length(bandwidth) != 1 ||
          !is.finite(bandwidth) || bandwidth <= 0) {
        stop("Gaussian RBF bandwidth must be a positive scalar", call. = FALSE)
      }
      h2 <- as.numeric(bandwidth)^2
    }
    obj <- list(type = "gaussian_rbf", h2 = h2,
                precon = validate_kernel_precon(precon))
    class(obj) <- c("SteinKernel_gaussian_rbf", "SteinKernel")
    return(obj)
  }

  if (!is.numeric(beta) || length(beta) != 1 || !is.finite(beta) || beta >= 0) {
    stop("beta must be a finite negative scalar", call. = FALSE)
  }
  if (!is.numeric(c) || length(c) != 1 || !is.finite(c) || c <= 0) {
    stop("c must be a finite positive scalar", call. = FALSE)
  }
  obj <- list(type = "imq", beta = as.numeric(beta), c = as.numeric(c),
              precon = validate_kernel_precon(precon))
  class(obj) <- c("SteinKernel_imq", "SteinKernel")
  obj
}

#' Print a Stein kernel
#'
#' One method for every kernel class in the package: the built-in Gaussian RBF
#' and IMQ kernels, the Stein Points inverse-log and score-distance kernels,
#' and callback kernels from [custom_stein_kernel()].
#'
#' @param x A `SteinKernel` object.
#' @param ... Ignored.
#' @return `x`, invisibly.
#' @examples
#' stein_kernel(type = "imq", c = 1, beta = -0.5)
#' @export
print.SteinKernel <- function(x, ...) {
  pars <- x[vapply(x, function(e) is.numeric(e) && length(e) == 1L, logical(1))]
  cat(sprintf(
    "Stein kernel <%s>%s%s\n", kernel_type_name(x),
    if (length(pars)) paste0("  ", paste(names(pars), unlist(pars),
                                         sep = "=", collapse = "  ")) else "",
    if (is.null(x$precon)) "" else sprintf("  precon=%dx%d", nrow(x$precon),
                                           ncol(x$precon))
  ))
  invisible(x)
}


# ---- 2. Pairwise Stein-kernel assembly -----------------------------------

# The default method is the canonical assembly path for every base kernel. A
# kernel supplies only its value, first derivative, and mixed-trace methods;
# the Stein identity below is kept in one place.

#' Assemble the pairwise Stein-kernel matrix
#'
#' Combines a base kernel and its derivatives with supplied target scores. This
#' function constructs \eqn{k_{0,p}}; it does not compute the score function.
#'
#' @details
#' Let \eqn{s_p(x)=\nabla_x\log p(x)}. From base kernel \eqn{k_\rho}, the
#' package constructs
#' \deqn{\begin{aligned}
#' k_{0,p}(x,y)={}&s_p(x)^\top s_p(y)k_\rho(x,y)\\
#' &+s_p(x)^\top\nabla_y k_\rho(x,y)
#' +s_p(y)^\top\nabla_x k_\rho(x,y)\\
#' &+\operatorname{tr}\left\{\nabla_x\nabla_y^\top
#' k_\rho(x,y)\right\}.
#' \end{aligned}}
#' For rows \eqn{x_i^\top} of `X` and \eqn{y_j^\top} of `Y`, the returned
#' matrix is
#' \deqn{K_{ij}=k_{0,p}(x_i,y_j).}
#'
#' Row order is part of the input contract: `X[i, ]` must correspond to
#' `grads[i, ]`, and `Y[j, ]` must correspond to `grads_Y[j, ]`. If `Y = NULL`,
#' the function uses \eqn{Y=X} and `grads_Y = grads`. A custom kernel supplies
#' the base-kernel matrices \eqn{B}, \eqn{G}, and \eqn{H} through
#' [custom_stein_kernel()]; this function assembles them with the scores into
#' \eqn{K}.
#'
#' @param kernel A `SteinKernel` object describing a base kernel and its
#'   derivatives.
#' @param X Numeric \eqn{n_X\times d} matrix with rows \eqn{x_i^\top}.
#' @param grads Numeric \eqn{n_X\times d} matrix with rows
#'   \eqn{s_p(x_i)^\top}.
#' @param Y Optional numeric \eqn{n_Y\times d} matrix with rows
#'   \eqn{y_j^\top}. `NULL` uses `X`.
#' @param grads_Y Numeric \eqn{n_Y\times d} matrix with rows
#'   \eqn{s_p(y_j)^\top}. Required when `Y` is supplied.
#' @param ... Additional arguments passed to kernel methods.
#'
#' @return
#' Numeric \eqn{n_X\times n_Y} Stein-kernel matrix \eqn{K}; if `Y = NULL`, it
#' is \eqn{n_X\times n_X}.
#' @examples
#' X <- matrix(c(-1, 0, 1), ncol = 1)
#' grads <- -X
#' kernel <- stein_kernel(type = "gaussian_rbf", h = 1)
#' stein_kernel_matrix(kernel, X, grads)
#' @export
stein_kernel_matrix <- function(kernel, X, grads, Y = NULL, grads_Y = NULL, ...) {
  UseMethod("stein_kernel_matrix")
}

#' @export
stein_kernel_matrix.default <- function(kernel, X, grads, Y = NULL, grads_Y = NULL, ...) {
  inp <- validate_cross_inputs(X, grads, Y, grads_Y)
  X <- inp$X; grads <- inp$grads; Y <- inp$Y; grads_Y <- inp$grads_Y
  tcrossprod(grads, grads_Y) * eval_kernel(kernel, X, Y, ...) +
    cross_kernel(kernel, X, grads, Y, grads_Y, ...) +
    trace_mixed_kernel(kernel, X, Y, ...)
}

# ---- 3. Pairwise Stein-kernel diagonal -----------------------------------

# `k0_diag()` returns the vector k0(x_i, x_i). It is an internal generic: the
# sequential algorithms (Stein Points, SP-MCMC, Stein thinning) need only the
# diagonal for a whole candidate batch, and every built-in kernel has a closed
# form for it because r(x, x) = 0 collapses the four Stein terms. Forming the
# full pairwise matrix to read its diagonal would be O(n^2) work and memory for
# an O(n) answer.

k0_diag <- function(kernel, X, S_X, ...) UseMethod("k0_diag")

# Any SteinKernel that implements the four leaf generics works through the
# general assembly. Evaluating one row at a time keeps memory O(n); `...`
# forwards options such as `precon` to custom-kernel callbacks.
#' @export
k0_diag.SteinKernel <- function(kernel, X, S_X, ...) {
  vapply(seq_len(nrow(X)), function(i) {
    stein_kernel_matrix(
      kernel,
      X[i, , drop = FALSE], S_X[i, , drop = FALSE],
      X[i, , drop = FALSE], S_X[i, , drop = FALSE],
      ...
    )[1L, 1L]
  }, numeric(1))
}

# r(x, x) = 0 leaves k(x, x) = 1, so only the mixed trace and the score norm
# survive.
#' @export
k0_diag.SteinKernel_gaussian_rbf <- function(kernel, X, S_X,
                                             precon = NULL, ...) {
  d <- ncol(X)
  M <- kernel_precon(kernel, precon, d)
  tr_M <- kernel_precon_trace(M, d)
  tr_M / resolve_gaussian_rbf_h2(kernel, X, precon = M) +
    rowSums(S_X * S_X)
}

# r(x, x) = 0 leaves the offset c^2 in every power of (c^2 + r).
#' @export
k0_diag.SteinKernel_imq <- function(kernel, X, S_X, precon = NULL, ...) {
  d <- ncol(X)
  a <- kernel$c^2
  b <- kernel$beta
  tr_M <- kernel_precon_trace(kernel_precon(kernel, precon, d), d)
  -2 * b * tr_M * a^(b - 1) + a^b * rowSums(S_X * S_X)
}


# ---- 4. The four Stein terms (+ FSSD grad_theta_v) -----------------------

# ---- Generics + defensive base methods -----------------------------------

#' Kernel extension interface
#'
#' These generics expose the base-kernel pieces used by package algorithms.
#' [stein_kernel_matrix()], KSD-U, and KSD-V use `eval_kernel()`,
#' `grad_x_kernel()`, and `trace_mixed_kernel()`. FSSD-rand and SVGD use the
#' first two, although [custom_stein_kernel()] still requires all three
#' callbacks. FSSD-opt with a fixed scale additionally uses
#' `grad_theta_v_kernel()` or numeric location derivatives; optimizing a custom
#' scale requires [kernel_scale2()] and analytic location and scale derivatives.
#'
#' For rows \eqn{x_i^\top} of \eqn{X} and \eqn{y_j^\top} of \eqn{Y}, the
#' base-kernel pages use \eqn{B} for values, \eqn{G} for first derivatives, and
#' \eqn{H} for mixed-derivative traces. [stein_kernel_matrix()] alone uses
#' \eqn{K_{ij}=k_{0,p}(x_i,y_j)} for the assembled Stein-kernel matrix.
#'
#' @name kernel_generics
#' @examples
#' X <- matrix(c(-1, 0, 1), ncol = 1)
#' kernel <- stein_kernel(type = "gaussian_rbf", h = 1)
#' eval_kernel(kernel, X)
#' grad_x_kernel(kernel, X)
#' trace_mixed_kernel(kernel, X)
NULL

#' Evaluate a base kernel
#'
#' For rows \eqn{x_i^\top} of `X` and \eqn{y_j^\top} of `Y`, returns
#' \deqn{B_{ij}=k_\rho(x_i,y_j).}
#'
#' @param obj A `SteinKernel` object.
#' @param X Numeric \eqn{n_X\times d} matrix.
#' @param Y Optional numeric \eqn{n_Y\times d} matrix. `NULL` uses `X`.
#' @param ... Additional arguments passed to the method.
#' @return Numeric \eqn{n_X\times n_Y} base-kernel matrix \eqn{B}.
#' @examples
#' X <- matrix(c(-1, 0, 1), ncol = 1)
#' eval_kernel(stein_kernel("gaussian_rbf", h = 1), X)
#' @export
eval_kernel <- function(obj, X, Y = NULL, ...) UseMethod("eval_kernel")

#' Differentiate a base kernel with respect to its first argument
#'
#' For rows \eqn{x_i^\top} of `X` and \eqn{y_j^\top} of `Y`, returns
#' \deqn{G_{ijr}=\frac{\partial k_\rho(x_i,y_j)}{\partial x_r}.}
#'
#' @param obj A `SteinKernel` object.
#' @param X Numeric \eqn{n_X\times d} matrix.
#' @param Y Optional numeric \eqn{n_Y\times d} matrix. `NULL` uses `X`.
#' @param ... Additional arguments passed to the method.
#' @return Numeric \eqn{n_X\times n_Y\times d} array \eqn{G}.
#' @export
grad_x_kernel <- function(obj, X, Y = NULL, ...) UseMethod("grad_x_kernel")

#' Compute the mixed-derivative trace of a base kernel
#'
#' For rows \eqn{x_i^\top} of `X` and \eqn{y_j^\top} of `Y`, returns
#' \deqn{H_{ij}=\operatorname{tr}\left\{\nabla_x\nabla_y^\top
#' k_\rho(x_i,y_j)\right\}.}
#'
#' @param obj A `SteinKernel` object.
#' @param X Numeric \eqn{n_X\times d} matrix.
#' @param Y Optional numeric \eqn{n_Y\times d} matrix. `NULL` uses `X`.
#' @param ... Additional arguments passed to the method.
#' @return Numeric \eqn{n_X\times n_Y} mixed-trace matrix \eqn{H}.
#' @export
trace_mixed_kernel <- function(obj, X, Y = NULL, ...) {
  UseMethod("trace_mixed_kernel")
}

#' Compute the score-derivative cross term
#'
#' Returns
#' \deqn{C_{ij}=s_p(x_i)^\top\nabla_y k_\rho(x_i,y_j)
#' +s_p(y_j)^\top\nabla_x k_\rho(x_i,y_j).}
#' This is one component of [stein_kernel_matrix()], not the complete
#' Stein-kernel matrix.
#'
#' @param obj A `SteinKernel` object.
#' @param X Numeric \eqn{n_X\times d} matrix.
#' @param grads Numeric \eqn{n_X\times d} score matrix for `X`.
#' @param Y Optional numeric \eqn{n_Y\times d} matrix. `NULL` uses `X`.
#' @param grads_Y Numeric \eqn{n_Y\times d} score matrix for `Y`. Required when
#'   `Y` is supplied.
#' @param ... Additional arguments passed to the method.
#' @return Numeric \eqn{n_X\times n_Y} cross-term matrix \eqn{C}.
#' @export
cross_kernel <- function(obj, X, grads, Y = NULL, grads_Y = NULL, ...) {
  UseMethod("cross_kernel")
}

#' Differentiate the local FSSD-opt objective
#'
#' @details
#' Let
#' \deqn{\xi_p(x,v;\rho)=s_p(x)k_\rho(x,v)+
#' \nabla_x k_\rho(x,v)}
#' and
#' \deqn{\mathcal{L}_j(v_j,\rho)=\sum_{i=1}^n
#' g_i^\top\xi_p(x_i,v_j;\rho),}
#' where row \eqn{i} of `g_block` is \eqn{g_i^\top}. The method returns
#' \deqn{\texttt{grad_vj}=\nabla_{v_j}\mathcal{L}_j(v_j,\rho)}
#' and, when the kernel exposes a squared scale \eqn{\rho},
#' \deqn{\texttt{grad_param}=
#' \frac{\partial\mathcal{L}_j(v_j,\rho)}{\partial\rho}.}
#'
#' @param obj A `SteinKernel` object.
#' @param X Numeric \eqn{n\times d} matrix with rows \eqn{x_i^\top}.
#' @param vj Numeric vector of length \eqn{d} giving test location \eqn{v_j}.
#' @param grads_X Numeric \eqn{n\times d} matrix with rows
#'   \eqn{s_p(x_i)^\top}.
#' @param g_block Numeric \eqn{n\times d} matrix with rows \eqn{g_i^\top}.
#' @param ... Additional arguments passed to the method.
#' @return A list containing `grad_vj`, a vector of length \eqn{d}, and
#'   `grad_param`, a scalar.
#' @export
grad_theta_v_kernel <- function(obj, X, vj, grads_X, g_block, ...) {
  UseMethod("grad_theta_v_kernel")
}

#' @export
eval_kernel.SteinKernel <- function(obj, X, Y = NULL, ...) {
  stop("No eval_kernel() method for this SteinKernel", call. = FALSE)
}
#' @export
grad_x_kernel.SteinKernel <- function(obj, X, Y = NULL, ...) {
  stop("No grad_x_kernel() method for this SteinKernel", call. = FALSE)
}
#' @export
trace_mixed_kernel.SteinKernel <- function(obj, X, Y = NULL, ...) {
  stop("No trace_mixed_kernel() method for this SteinKernel", call. = FALSE)
}
#' @export
cross_kernel.SteinKernel <- function(obj, X, grads, Y = NULL,
                                     grads_Y = NULL, precon = NULL, ...) {
  inp <- validate_cross_inputs(X, grads, Y, grads_Y)
  X <- inp$X; grads <- inp$grads; Y <- inp$Y; grads_Y <- inp$grads_Y
  n_x <- nrow(X); n_y <- nrow(Y); d <- ncol(X)

  grad_x <- grad_x_kernel(obj, X, Y, precon = precon, ...)
  # Symmetry gives grad_y k(x, y) = grad_x k(y, x). When X and Y are the
  # same checked matrices, reuse the first derivative array rather than asking
  # the kernel to repeat the work.
  grad_y_reverse <- if (identical(X, Y)) {
    grad_x
  } else {
    grad_x_kernel(obj, Y, X, precon = precon, ...)
  }

  out <- matrix(0, n_x, n_y)
  for (j in seq_len(d)) {
    grad_x_j <- matrix(grad_x[, , j], n_x, n_y)
    grad_y_j <- t(matrix(grad_y_reverse[, , j], n_y, n_x))
    out <- out +
      matrix(grads[, j], n_x, n_y) * grad_y_j +
      matrix(grads_Y[, j], n_x, n_y, byrow = TRUE) * grad_x_j
  }
  out
}
#' @export
grad_theta_v_kernel.SteinKernel <- function(obj, X, vj, grads_X, g_block, ...) {
  stop("No grad_theta_v_kernel() method for this SteinKernel", call. = FALSE)
}

# ---- Term 1: eval_kernel  k(x,y) -----------------------------------------

#' @export
eval_kernel.SteinKernel_gaussian_rbf <- function(obj, X, Y = NULL,
                                                 precon = NULL, ...) {
  inp <- validate_kernel_xy(X, Y)
  X <- inp$X; Y <- inp$Y
  M <- kernel_precon(obj, precon, ncol(X))
  sq_dist <- compute_cross_squared_distance(X, Y, M)
  h2 <- resolve_gaussian_rbf_h2(obj, X, Y, precon = M)
  exp(-sq_dist / (2 * h2))
}

#' @export
eval_kernel.SteinKernel_imq <- function(obj, X, Y = NULL, precon = NULL, ...) {
  inp <- validate_kernel_xy(X, Y)
  X <- inp$X; Y <- inp$Y
  M <- kernel_precon(obj, precon, ncol(X))
  sq_dist <- compute_cross_squared_distance(X, Y, M)
  (obj$c^2 + sq_dist)^obj$beta
}

# ---- Term 2: grad_x_kernel  grad_x k  (n_x by n_y by d array) ------------

#' @export
grad_x_kernel.SteinKernel_gaussian_rbf <- function(obj, X, Y = NULL,
                                                   precon = NULL, ...) {
  inp <- validate_kernel_xy(X, Y)
  X <- inp$X; Y <- inp$Y
  n_x <- nrow(X); n_y <- nrow(Y); d <- ncol(X)
  M <- kernel_precon(obj, precon, d)
  sq_dist <- compute_cross_squared_distance(X, Y, M)
  h2 <- resolve_gaussian_rbf_h2(obj, X, Y, precon = M)
  k_mat <- exp(-sq_dist / (2 * h2))
  grad_arr <- array(0, dim = c(n_x, n_y, d))
  X_lin <- if (is.null(M)) X else X %*% M
  Y_lin <- if (is.null(M)) Y else Y %*% M
  coef <- -1 / h2
  for (j in seq_len(d)) {
    grad_arr[, , j] <- coef * outer(X_lin[, j], Y_lin[, j], "-") * k_mat
  }
  grad_arr
}

#' @export
grad_x_kernel.SteinKernel_imq <- function(obj, X, Y = NULL,
                                         precon = NULL, ...) {
  inp <- validate_kernel_xy(X, Y)
  X <- inp$X; Y <- inp$Y
  n_x <- nrow(X); n_y <- nrow(Y); d <- ncol(X)
  M <- kernel_precon(obj, precon, d)
  sq_dist <- compute_cross_squared_distance(X, Y, M)
  X_lin <- if (is.null(M)) X else X %*% M
  Y_lin <- if (is.null(M)) Y else Y %*% M
  factor_mat <- 2 * obj$beta * (obj$c^2 + sq_dist)^(obj$beta - 1)
  grad_arr <- array(0, dim = c(n_x, n_y, d))
  for (j in seq_len(d)) {
    grad_arr[, , j] <- factor_mat * outer(X_lin[, j], Y_lin[, j], "-")
  }
  grad_arr
}

# ---- Term 3: trace_mixed_kernel  tr(grad_x grad_y^T k) -------------------

#' @export
trace_mixed_kernel.SteinKernel_gaussian_rbf <- function(obj, X, Y = NULL,
                                                        precon = NULL, ...) {
  inp <- validate_kernel_xy(X, Y)
  X <- inp$X; Y <- inp$Y
  M <- kernel_precon(obj, precon, ncol(X))
  h2 <- resolve_gaussian_rbf_h2(obj, X, Y, precon = M)
  sq <- compute_cross_squared_distance(X, Y, M)
  sq_m2 <- if (is.null(M)) sq else compute_cross_precon2_distance(X, Y, M)
  k_mat <- exp(-sq / (2 * h2))
  tr_M <- kernel_precon_trace(M, ncol(X))
  k_mat * ((tr_M / h2) - (sq_m2 / (h2^2)))
}

#' @export
trace_mixed_kernel.SteinKernel_imq <- function(obj, X, Y = NULL,
                                              precon = NULL, ...) {
  inp <- validate_kernel_xy(X, Y)
  X <- inp$X; Y <- inp$Y
  M <- kernel_precon(obj, precon, ncol(X))
  sq_dist <- compute_cross_squared_distance(X, Y, M)
  sq_m2 <- if (is.null(M)) sq_dist else compute_cross_precon2_distance(X, Y, M)
  tr_M <- kernel_precon_trace(M, ncol(X))
  s <- obj$c^2 + sq_dist
  -4 * obj$beta * (obj$beta - 1) * sq_m2 * s^(obj$beta - 2) -
    2 * obj$beta * tr_M * s^(obj$beta - 1)
}

# ---- Term 4: cross_kernel -------------------------------------------------
# The base-class method above derives the score/derivative coupling from
# grad_x_kernel() for every symmetric base kernel. Built-ins and callback
# kernels intentionally share that single assembly path.

# ---- FSSD term: grad_theta_v_kernel  (gradient wrt location vj) ----------

#' @export
grad_theta_v_kernel.SteinKernel_gaussian_rbf <- function(
    obj, X, vj, grads_X, g_block, precon = NULL, ...) {
  h2 <- obj$h2
  n <- nrow(X); d <- ncol(X)
  M <- kernel_precon(obj, precon, d)
  vj_mat <- matrix(vj, nrow = n, ncol = d, byrow = TRUE)
  delta <- X - vj_mat
  M_delta <- if (is.null(M)) delta else delta %*% M
  sq_norm <- rowSums(M_delta * delta)
  k_xv <- exp(-sq_norm / (2 * h2))
  b <- grads_X - (1 / h2) * M_delta
  feature_weight <- rowSums(g_block * b)
  weighted_feature <- k_xv * feature_weight
  gM <- if (is.null(M)) g_block else g_block %*% M
  list(
    grad_vj = (1 / h2) * (colSums(M_delta * weighted_feature) + colSums(gM * k_xv)),
    grad_param = sum((sq_norm / (2 * h2^2)) * weighted_feature) +
      (1 / h2^2) * sum(k_xv * rowSums(g_block * M_delta))
  )
}

#' @export
grad_theta_v_kernel.SteinKernel_imq <- function(
    obj, X, vj, grads_X, g_block, precon = NULL, ...) {
  beta <- obj$beta; c_param <- obj$c
  n <- nrow(X); d <- ncol(X)
  M <- kernel_precon(obj, precon, d)
  vj_mat <- matrix(vj, nrow = n, ncol = d, byrow = TRUE)
  delta <- X - vj_mat
  M_delta <- if (is.null(M)) delta else delta %*% M
  sq_norm <- rowSums(M_delta * delta)
  s <- c_param^2 + sq_norm
  t_coef <- 2 * beta * s^(beta - 1)
  u_coef <- 4 * beta * (beta - 1) * s^(beta - 2)
  a_vec <- rowSums(g_block * grads_X)
  b_vec <- rowSums(g_block * M_delta)
  gM <- if (is.null(M)) g_block else g_block %*% M
  grad_vj <- colSums(M_delta * (-t_coef * a_vec - u_coef * b_vec)) +
    colSums(gM * (-t_coef))
  # FSSD-opt differentiates with respect to c^2, so no 2c factor is needed.
  grad_param <- sum((t_coef / 2) * a_vec + (u_coef / 2) * b_vec)
  list(grad_vj = grad_vj, grad_param = grad_param)
}

# ---- FSSD squared-scale hook ---------------------------------------------

#' Read or replace a kernel's squared scale
#'
#' The squared scale is denoted by \eqn{\rho}: \eqn{\rho=h^2} for Gaussian RBF
#' and \eqn{\rho=c^2} for IMQ. With no `value`, a positive number means the
#' scale is set, `NA_real_` means the kernel supports a scale but it is unset,
#' and `NULL` means the kernel has no scale interface. With `value`, the
#' function returns an updated copy of the kernel.
#'
#' @param obj A kernel object.
#' @param value Optional positive squared scale \eqn{\rho}.
#'
#' @return The current squared scale, `NA_real_`, or `NULL` when `value` is
#'   omitted; otherwise the updated kernel object.
#'
#' @examples
#' k <- stein_kernel(type = "gaussian_rbf", h = 2)
#' kernel_scale2(k)
#' kernel_scale2(kernel_scale2(k, 9))
#' kernel_scale2(stein_kernel_inverse_log(alpha = 1, beta = -1))
#' @export
kernel_scale2 <- function(obj, value = NULL) UseMethod("kernel_scale2")

#' @export
kernel_scale2.default <- function(obj, value = NULL) {
  if (is.null(value)) return(NULL)
  stop("this kernel does not support scale optimization", call. = FALSE)
}

#' @export
kernel_scale2.SteinKernel_gaussian_rbf <- function(obj, value = NULL) {
  if (is.null(value)) {
    return(if (is.null(obj$h2)) NA_real_ else as.numeric(obj$h2))
  }
  obj$h2 <- validate_kernel_squared_scale(value)
  obj
}

#' @export
kernel_scale2.SteinKernel_imq <- function(obj, value = NULL) {
  if (is.null(value)) return(as.numeric(obj$c)^2)
  obj$c <- sqrt(validate_kernel_squared_scale(value))
  obj
}

# ---- 5. Internal kernel utilities ----------------------------------------

# Resolve a string / SteinKernel into an object with a scalar scale set.
instantiate_kernel <- function(kernel_choice, scale_val, beta = -0.5, precon = NULL) {
  if (inherits(kernel_choice, "SteinKernel")) return(kernel_choice)
  if (!is.character(kernel_choice) || length(kernel_choice) != 1) {
    stop("kernel must be 'gaussian_rbf', 'imq', or a SteinKernel object", call. = FALSE)
  }
  scale_val <- validate_kernel_squared_scale(scale_val)
  kernel_type <- match.arg(kernel_choice, c("gaussian_rbf", "imq"))
  if (kernel_type == "gaussian_rbf") {
    return(stein_kernel(type = "gaussian_rbf", h = sqrt(scale_val), precon = precon))
  }
  # scale_val is a squared scale (median of squared distances); the IMQ length
  # scale c satisfies c^2 = scale_val, so the offset in (c^2 + r(x,y))^beta
  # is on the same squared-distance scale as the RBF h^2 convention.
  stein_kernel(type = "imq", c = sqrt(scale_val), beta = beta, precon = precon)
}

# Validate a squared kernel scale before inserting it into an existing object.
validate_kernel_squared_scale <- function(scale_val) {
  if (!is.numeric(scale_val) || length(scale_val) != 1L ||
      !is.finite(scale_val) || scale_val <= 0) {
    stop("scaling must be a positive scalar", call. = FALSE)
  }
  as.numeric(scale_val)
}

# Sequential fixed-KSD algorithms require one RBF bandwidth throughout. SVGD
# is the intentional exception: its paper recomputes a dynamic bandwidth at
# every particle iteration before evaluating the update.
require_fixed_gaussian_rbf <- function(kernel, caller) {
  if (inherits(kernel, "SteinKernel_gaussian_rbf") && is.null(kernel$h2)) {
    stop(
      sprintf(
        "%s requires a Gaussian RBF kernel with fixed h; dynamic median bandwidth is supported only by SVGD.",
        caller
      ),
      call. = FALSE
    )
  }
  invisible(kernel)
}

# Flatten "unsupported" and "unset" to NA for result reporting.
kernel_scaling_value <- function(kernel_obj) {
  scale2 <- kernel_scale2(kernel_obj)
  if (is.null(scale2)) NA_real_ else as.numeric(scale2)
}

# Human-readable kernel type name.
kernel_type_name <- function(kernel_obj) {
  if (!inherits(kernel_obj, "SteinKernel")) return("unknown")
  if (inherits(kernel_obj, "SteinKernel_gaussian_rbf")) return("gaussian_rbf")
  if (inherits(kernel_obj, "SteinKernel_imq")) return("imq")
  if (inherits(kernel_obj, "SteinKernel_imq_score")) return("imq_score")
  if (inherits(kernel_obj, "SteinKernel_inverse_log")) return("inverse_log")
  if (inherits(kernel_obj, "SteinKernel_custom")) return("custom")
  "SteinKernel"
}


# ---- 6. Internal primitives shared by the terms --------------------------

# Pairwise squared distances between rows of X and Y (Y = X if NULL). If M is
# supplied, distance is (x-y)^T M (x-y).
compute_cross_squared_distance <- function(X, Y = NULL, M = NULL) {
  if (!is.null(M)) {
    X_M <- X %*% M
  } else {
    X_M <- X
  }
  if (is.null(Y)) {
    x_norm <- rowSums(X_M * X)
    x2 <- matrix(x_norm, nrow = length(x_norm), ncol = length(x_norm))
    return(x2 + t(x2) - 2 * tcrossprod(X_M, X))
  }
  Y_M <- if (is.null(M)) Y else Y %*% M
  x_norm <- rowSums(X_M * X)
  y_norm <- rowSums(Y_M * Y)
  outer(x_norm, y_norm, "+") - 2 * tcrossprod(X_M, Y)
}

# Squared Euclidean distance after applying M once: (x-y)^T M^2 (x-y).
compute_cross_precon2_distance <- function(X, Y = NULL, M = NULL) {
  if (is.null(M)) return(compute_cross_squared_distance(X, Y))
  compute_cross_squared_distance(
    X %*% M,
    if (is.null(Y)) NULL else Y %*% M
  )
}

# Resolve the gaussian_rbf bandwidth^2: stored h2 if present, else the exact
# all-pair median heuristic over X / rbind(X, Y).
resolve_gaussian_rbf_h2 <- function(obj, X, Y = NULL, precon = NULL) {
  if (!is.null(obj$h2)) return(obj$h2)
  Z <- if (is.null(Y) || identical(X, Y)) X else rbind(X, Y)
  if (nrow(Z) < 2L) return(1)
  M <- kernel_precon(obj, precon, ncol(Z))
  if (is.null(M)) {
    h2 <- find_median_distance(Z)
  } else {
    h2 <- find_median_distance(Z %*% t(chol(M)))
  }
  if (!is.finite(h2) || h2 <= 0) h2 <- 1
  h2
}

# Resolve the object-owned preconditioner, with an explicit method argument as
# a temporary override. The dimension check lives here because constructors do
# not yet know the dimension of future point matrices.
kernel_precon <- function(obj, precon = NULL, d = NULL) {
  M <- if (!is.null(precon)) precon else obj$precon
  validate_kernel_precon(M, d)
}

kernel_precon_trace <- function(M, d) {
  if (is.null(M)) d else sum(diag(M))
}

# Validate and coerce a pair of point collections for all public leaf methods.
# `y_was_null` lets callback methods preserve their documented Y = NULL call
# contract while still validating the expected output dimensions.
validate_kernel_xy <- function(X, Y = NULL) {
  X <- .as_rows(X, "X")
  y_was_null <- is.null(Y)
  Y <- if (y_was_null) X else .as_rows(Y, "Y")
  if (ncol(X) != ncol(Y)) {
    stop("X and Y must have the same number of columns", call. = FALSE)
  }
  list(X = X, Y = Y, y_was_null = y_was_null)
}

# Validate / coerce the (X, grads, Y, grads_Y) tuple shared by cross & assembly.
validate_cross_inputs <- function(X, grads, Y = NULL, grads_Y = NULL) {
  X <- .as_rows(X, "X")
  grads <- as.matrix(grads)
  if (!is.numeric(grads) || nrow(grads) != nrow(X) || ncol(grads) != ncol(X) ||
      any(!is.finite(grads))) {
    stop("grads must be a finite numeric matrix with the same shape as X", call. = FALSE)
  }
  if (is.null(Y)) {
    Y <- X
    grads_Y <- grads
  } else {
    Y <- .as_rows(Y, "Y")
    if (ncol(X) != ncol(Y)) stop("X and Y must have the same number of columns", call. = FALSE)
    if (is.null(grads_Y)) stop("grads_Y must be provided when Y is not NULL", call. = FALSE)
    grads_Y <- as.matrix(grads_Y)
    if (!is.numeric(grads_Y) || nrow(grads_Y) != nrow(Y) || ncol(grads_Y) != ncol(Y) ||
        any(!is.finite(grads_Y))) {
      stop("grads_Y must be a finite numeric matrix with the same shape as Y", call. = FALSE)
    }
  }
  list(X = X, grads = grads, Y = Y, grads_Y = grads_Y)
}
