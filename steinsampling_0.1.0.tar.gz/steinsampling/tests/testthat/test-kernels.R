test_that("built-in Stein kernel generics return finite arrays and matrices", {
  X <- small_x(4)
  S <- normal_score(X)
  kernel <- stein_kernel(type = "gaussian_rbf", h = 1)

  K <- eval_kernel(kernel, X)
  G <- grad_x_kernel(kernel, X)
  T <- trace_mixed_kernel(kernel, X)
  C <- cross_kernel(kernel, X, S)
  K0 <- stein_kernel_matrix(kernel, X, S)
  theta_grad <- grad_theta_v_kernel(
    kernel,
    X = X,
    vj = 0,
    grads_X = S,
    g_block = matrix(1, nrow(X), ncol(X))
  )

  expect_s3_class(kernel, "SteinKernel_gaussian_rbf")
  expect_equal(dim(K), c(4L, 4L))
  expect_equal(dim(G), c(4L, 4L, 1L))
  expect_equal(dim(T), c(4L, 4L))
  expect_equal(dim(C), c(4L, 4L))
  expect_equal(dim(K0), c(4L, 4L))
  expect_finite_numeric(K)
  expect_finite_numeric(G)
  expect_finite_numeric(T)
  expect_finite_numeric(C)
  expect_finite_numeric(K0)
  expect_length(theta_grad$grad_vj, 1L)
  expect_finite_numeric(theta_grad$grad_vj)
  expect_finite_numeric(theta_grad$grad_param)
})

test_that("IMQ and inverse-log Stein kernels are usable kernel objects", {
  X <- small_x(4)
  S <- normal_score(X)
  imq <- stein_kernel(type = "imq", c = 1, beta = -0.5)
  inverse_log <- stein_kernel_inverse_log(alpha = 1, beta = -1)

  expect_s3_class(imq, "SteinKernel_imq")
  expect_s3_class(inverse_log, "SteinKernel_inverse_log")
  expect_equal(dim(stein_kernel_matrix(imq, X, S)), c(4L, 4L))
  expect_equal(dim(stein_kernel_matrix(inverse_log, X, S)), c(4L, 4L))
  expect_finite_numeric(stein_kernel_matrix(imq, X, S))
  expect_finite_numeric(stein_kernel_matrix(inverse_log, X, S))
})

test_that("custom Stein kernels follow the generic contract", {
  eval_fn <- function(X, Y = NULL, precon = NULL) {
    X <- as.matrix(X)
    Y <- if (is.null(Y)) X else as.matrix(Y)
    diff <- outer(X[, 1], Y[, 1], "-")
    exp(-0.5 * diff^2)
  }
  grad_fn <- function(X, Y = NULL, precon = NULL) {
    X <- as.matrix(X)
    Y <- if (is.null(Y)) X else as.matrix(Y)
    diff <- outer(X[, 1], Y[, 1], "-")
    array(-diff * exp(-0.5 * diff^2), dim = c(nrow(X), nrow(Y), 1L))
  }
  trace_fn <- function(X, Y = NULL, precon = NULL) {
    X <- as.matrix(X)
    Y <- if (is.null(Y)) X else as.matrix(Y)
    diff <- outer(X[, 1], Y[, 1], "-")
    (1 - diff^2) * exp(-0.5 * diff^2)
  }

  kernel <- custom_stein_kernel(eval_fn, grad_fn, trace_fn, custom_grad_mode = "numeric")
  X <- small_x(3)
  S <- normal_score(X)

  expect_s3_class(kernel, "SteinKernel_custom")
  expect_equal(dim(eval_kernel(kernel, X)), c(3L, 3L))
  expect_equal(dim(grad_x_kernel(kernel, X)), c(3L, 3L, 1L))
  expect_equal(dim(trace_mixed_kernel(kernel, X)), c(3L, 3L))
  expect_equal(dim(cross_kernel(kernel, X, S)), c(3L, 3L))
  expect_equal(dim(stein_kernel_matrix(kernel, X, S)), c(3L, 3L))
  expect_length(grad_theta_v_kernel(kernel, X, 0, S, matrix(1, 3, 1))$grad_vj, 1L)
})
