test_that("FSSD primitives return finite statistics and null summaries", {
  set.seed(5)
  X <- small_x(6)
  S <- normal_score(X)
  V <- matrix(0, ncol = 1)
  kernel <- stein_kernel(type = "gaussian_rbf", h = 1)

  tau <- compute_tau(X, S, V, kernel)
  stat <- compute_fssd_unbiased_stat(tau)
  null <- compute_fssd_null_pvalue(tau, fssd_stat = stat, n_simulations = 5)

  expect_equal(dim(tau), c(6L, 1L))
  expect_finite_numeric(tau)
  expect_length(stat, 1L)
  expect_finite_numeric(stat)
  expect_true(is.list(null))
  expect_true(null$p_value >= 0 && null$p_value <= 1)
  expect_finite_numeric(null$test_score)
  expect_finite_numeric(null$eigenvalues)
})

test_that("FSSD rand and opt tests run with small settings", {
  set.seed(6)
  X <- small_x(10)

  rand <- fssd_rand_test(X, normal_score, J = 1, nboot = 5, scaling = 1, seed = 1)
  dispatcher <- fssd_test(
    X, normal_score, variant = "rand", J = 1, nboot = 5,
    scaling = 1, seed = 1
  )
  opt <- fssd_opt_test(
    X, normal_score, J = 1, nboot = 5, scaling = 1,
    train_ratio = 0.5, eval_on = "all", maxit = 1, seed = 1
  )

  expect_valid_htest(rand)
  expect_valid_htest(dispatcher)
  expect_valid_htest(opt)
  expect_equal(rand$info$variant, "rand")
  expect_equal(opt$info$variant, "opt")
})
