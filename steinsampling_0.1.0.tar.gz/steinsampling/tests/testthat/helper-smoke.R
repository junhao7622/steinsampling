normal_score <- function(X) -as.matrix(X)

normal_log_p <- function(X) {
  X <- as.matrix(X)
  -0.5 * rowSums(X * X)
}

small_x <- function(n = 6L) {
  matrix(seq(-1, 1, length.out = n), ncol = 1)
}

expect_finite_numeric <- function(x) {
  expect_true(is.numeric(x))
  expect_true(all(is.finite(x)))
}

expect_valid_htest <- function(x) {
  expect_s3_class(x, "htest")
  expect_true(is.numeric(x$statistic))
  expect_true(length(x$statistic) >= 1L)
  expect_true(all(is.finite(x$statistic)))
  expect_true(is.numeric(x$p.value))
  expect_length(x$p.value, 1L)
  expect_true(is.finite(x$p.value))
  expect_true(x$p.value >= 0 && x$p.value <= 1)
}

toy_objective_1d <- function(X) {
  X <- as.matrix(X)
  list(
    f_vec = as.numeric((X[, 1] - 0.25)^2),
    D_new = -X
  )
}

toy_objective_2d <- function(X) {
  X <- as.matrix(X)
  center <- matrix(c(0.25, -0.25), nrow(X), 2L, byrow = TRUE)
  list(
    f_vec = rowSums((X - center)^2),
    D_new = -X
  )
}

smoke_tested_exports <- c(
  "build_precision_cache",
  "compute_fssd_null_pvalue",
  "compute_fssd_unbiased_stat",
  "compute_tau",
  "cross_kernel",
  "custom_adjusted_gradient",
  "custom_stein_kernel",
  "eval_kernel",
  "find_median_distance",
  "fmin_grid",
  "fmin_mc",
  "fmin_nm",
  "fssd_opt_test",
  "fssd_rand_test",
  "fssd_test",
  "get_component_mean",
  "get_score_evaluator",
  "gmm",
  "grad_theta_v_kernel",
  "grad_x_kernel",
  "grw",
  "grwmetrop",
  "ksd_u_bootstrap",
  "ksd_u_statistic",
  "ksd_u_test",
  "ksd_uq_matrix",
  "ksd_v_bootstrap",
  "ksd_v_statistic",
  "ksd_v_test",
  "ksd_vq_matrix",
  "likelihoodgmm",
  "mala",
  "perturbgmm",
  "plotgmm",
  "posteriorgmm",
  "prepare_ksd_u_inputs",
  "rgmm",
  "row_logsumexp",
  "rwm",
  "sample_proposal_box",
  "scorefunctiongmm",
  "sp_mcmc",
  "sp_mcmc_criterion",
  "sp_mcmc_eval_candidates",
  "sp_mcmc_select_start",
  "sp_mcmc_state",
  "stein_codescent",
  "stein_kernel",
  "stein_kernel_imq_score",
  "stein_kernel_inverse_log",
  "stein_kernel_matrix",
  "stein_points",
  "stein_thinning",
  "svgd",
  "trace_mixed_kernel",
  "update_svgd",
  "with_local_seed"
)
