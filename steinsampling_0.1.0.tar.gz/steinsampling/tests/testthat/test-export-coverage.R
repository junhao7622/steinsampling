test_that("all exported functions have smoke test coverage", {
  expect_setequal(getNamespaceExports("steinsampling"), smoke_tested_exports)
})
